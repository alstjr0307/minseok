#include<stdio.h>
int main(void)
{
  int i;
  int j;
  int mul;
  for(i=2; i<=9; i++)
  {
    for(j=1; j<=9; j++)
    {
      mul=i*j;
      printf("%d X %d = %d\n",i,j,mul);
    }
  }
}

